SELECT
    table_name,
    ordinal_position,
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name IN (
      'departments',
      'roles',
      'permissions',
      'role_permissions',
      'users',
      'user_roles',
      'system_settings',
      'feature_flags',
      'ai_models',
      'report_templates'
  )
ORDER BY table_name, ordinal_position;